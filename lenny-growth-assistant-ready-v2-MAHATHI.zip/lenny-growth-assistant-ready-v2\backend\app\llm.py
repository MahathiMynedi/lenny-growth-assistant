import httpx
from .config import settings
SYSTEM='''You are Lenny Growth Assistant. Answer ONLY from the supplied Lenny Podcast transcript excerpts. If the excerpts do not support the answer, say that clearly. Cite sources as [Source N]. Be concise and practical.'''
async def generate(question,context):
    if not context:return "I couldn't find supporting material in the transcript knowledge base for that question."
    joined='\n\n'.join(f"[Source {i+1}] {c['guest']} — {c['title']}\n{c['content']}" for i,c in enumerate(context))
    prompt=f'{SYSTEM}\n\nTranscript excerpts:\n{joined}\n\nQuestion: {question}\nAnswer:'
    if settings.llm_provider.lower()=='anthropic':
        if not settings.anthropic_api_key: raise RuntimeError('Anthropic provider selected but ANTHROPIC_API_KEY is missing.')
        from anthropic import AsyncAnthropic
        m=await AsyncAnthropic(api_key=settings.anthropic_api_key).messages.create(model=settings.anthropic_model,max_tokens=900,messages=[{'role':'user','content':prompt}])
        return m.content[0].text
    try:
        async with httpx.AsyncClient(timeout=settings.model_timeout_seconds) as client:
            r=await client.post(f'{settings.ollama_url}/api/generate',json={'model':settings.ollama_model,'prompt':prompt,'stream':False})
            r.raise_for_status(); return r.json().get('response','').strip() or 'The model returned an empty response.'
    except Exception as e: raise RuntimeError(f'Ollama unavailable: {e}')
