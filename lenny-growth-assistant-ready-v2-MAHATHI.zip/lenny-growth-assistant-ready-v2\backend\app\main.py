import uuid, logging
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .db import get_conn, init_db
from .rag import search
from .llm import generate
from .config import settings

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
log = logging.getLogger('lenny')

app = FastAPI(title='Lenny Growth Assistant', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

FRONTEND = Path('/frontend')
app.mount('/static', StaticFiles(directory=FRONTEND), name='static')

class ChatRequest(BaseModel):
    session_id: str
    message: str = Field(min_length=1, max_length=10000)

class SessionResponse(BaseModel):
    session_id: str

@app.on_event('startup')
def startup():
    try:
        init_db()
    except Exception as e:
        log.error('database initialization failed: %s', e)

@app.get('/health')
def health():
    db = 'ok'
    try:
        with get_conn() as c:
            c.execute('SELECT 1')
    except Exception:
        db = 'unavailable'
    return {'status': 'ok' if db == 'ok' else 'degraded', 'database': db}

@app.post('/sessions', response_model=SessionResponse)
def new_session():
    sid = str(uuid.uuid4())
    try:
        with get_conn() as c:
            c.execute('INSERT INTO sessions(id) VALUES(%s)', (sid,))
            c.commit()
        return {'session_id': sid}
    except Exception as e:
        raise HTTPException(503, f'Database unavailable: {e}')

@app.get('/sessions/{sid}/messages')
def messages(sid: str):
    with get_conn() as c:
        return c.execute('SELECT role,content,created_at FROM messages WHERE session_id=%s ORDER BY id', (sid,)).fetchall()

@app.post('/chat')
async def chat(req: ChatRequest):
    try:
        with get_conn() as c:
            c.execute("INSERT INTO messages(session_id,role,content) VALUES(%s,'user',%s)", (req.session_id, req.message))
            c.commit()
        ctx = search(req.message)
        answer = await generate(req.message, ctx)
        sources = [{'guest': x['guest'], 'title': x['title'], 'url': x['source_url'], 'score': x['score']} for x in ctx]
        with get_conn() as c:
            c.execute("INSERT INTO messages(session_id,role,content) VALUES(%s,'assistant',%s)", (req.session_id, answer))
            c.commit()
        return {'answer': answer, 'sources': sources, 'provider': settings.llm_provider}
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except Exception:
        log.exception('chat failed')
        raise HTTPException(500, 'Chat request failed. Check logs.')

@app.post('/artifact')
async def artifact(req: ChatRequest):
    ctx = search(req.message)
    answer = await generate(req.message, ctx)
    safe = answer.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    html = '''<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:Inter,Arial,sans-serif;max-width:850px;margin:40px auto;padding:0 24px;line-height:1.65;color:#182033}
    h1{font-size:28px}.source{font-size:13px;color:#667085}
    </style></head><body><h1>Generated Growth Artifact</h1><div>''' + safe.replace('\n', '<br>') + '''</div></body></html>'''
    return {'html': html, 'format': 'html', 'sources': [{'guest': x['guest'], 'title': x['title'], 'url': x['source_url']} for x in ctx]}

@app.get('/')
def root():
    return FileResponse(FRONTEND / 'index.html')
