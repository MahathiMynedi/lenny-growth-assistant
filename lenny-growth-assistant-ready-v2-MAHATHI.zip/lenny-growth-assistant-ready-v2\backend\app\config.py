from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_name:str='Lenny Growth Assistant'
    database_url:str='postgresql://lenny:lenny@db:5432/lenny'
    ollama_url:str='http://host.docker.internal:11434'
    ollama_model:str='llama3.2:3b'
    llm_provider:str='ollama'
    anthropic_api_key:str|None=None
    anthropic_model:str='claude-3-5-haiku-latest'
    model_timeout_seconds:float=45
    model_config=SettingsConfigDict(env_file='.env',extra='ignore')
settings=Settings()
