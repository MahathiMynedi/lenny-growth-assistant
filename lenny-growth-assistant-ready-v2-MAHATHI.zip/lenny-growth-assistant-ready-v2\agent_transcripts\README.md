# Agent transcripts
Add the coding-agent prompts, failed attempts, fixes, and validation notes used during development. Remove secrets before committing.
