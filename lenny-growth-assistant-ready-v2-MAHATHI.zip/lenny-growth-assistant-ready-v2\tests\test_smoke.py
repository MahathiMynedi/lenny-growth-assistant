from pathlib import Path
def test_required_docs_exist():
    root=Path(__file__).parents[1]
    for f in ['README.md','PRD.md','design.md','architecture.md','.env.example','docker-compose.yml']: assert (root/f).exists()
def test_artifact_viewer():
    h=(Path(__file__).parents[1]/'frontend/index.html').read_text();assert 'Artifact Viewer' in h and 'sandbox' in h
