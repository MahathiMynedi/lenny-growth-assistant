# Lenny Growth Assistant
A grounded product/growth assistant using FastAPI, PostgreSQL, Ollama, transcript retrieval, and an in-app artifact viewer.
## Quick start
Prerequisites: Docker Desktop, Ollama, Python 3.12+.
```bash
docker compose up --build
ollama pull llama3.2:3b
```
Initialize transcript data from a terminal with Python installed:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
$env:DATABASE_URL="postgresql://lenny:lenny@localhost:5432/lenny"
python backend/ingest.py
```
Open http://localhost:8000.
Set `LLM_PROVIDER=anthropic` plus `ANTHROPIC_API_KEY` for cloud evaluation. Logs: `docker compose logs api`. Health: `/health`. Tests: `pytest -q`.
