import re
from .db import get_conn
STOP=set('the a an and or to of in on for with is are was were be this that how what why from about can do does i we you they it as at by'.split())
def tokenize(s): return [x for x in re.findall(r"[a-z0-9']+",s.lower()) if x not in STOP and len(x)>2]
def search(query,limit=6):
    terms=tokenize(query)
    if not terms:return []
    with get_conn() as c: rows=c.execute('SELECT id,source_id,guest,title,source_url,content FROM chunks').fetchall()
    scored=[]; q=set(terms)
    for r in rows:
        toks=tokenize(r['content']); score=sum(toks.count(t) for t in q)
        if score: scored.append((score,r))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [r|{'score':s} for s,r in scored[:limit]]
