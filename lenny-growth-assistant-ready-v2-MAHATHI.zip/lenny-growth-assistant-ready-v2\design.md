# Design
Evidence first, calm focused workspace, progressive disclosure, safe-by-default artifact rendering, and responsive layout. The UI has clear empty, answer, unsupported, error, and artifact states. Controls are semantic and keyboard accessible.
