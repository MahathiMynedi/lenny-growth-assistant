import io,re,zipfile,urllib.request,pathlib
from app.db import init_db,get_conn
URL='https://github.com/ChatPRD/lennys-podcast-transcripts/archive/refs/heads/main.zip'
def chunks(text,size=1800,overlap=250):
    out=[];start=0
    while start<len(text):
        end=min(len(text),start+size);out.append(text[start:end])
        if end==len(text):break
        start=end-overlap
    return out
def main():
    init_db();data=urllib.request.urlopen(URL,timeout=30).read();z=zipfile.ZipFile(io.BytesIO(data));added=0;episodes=0
    with get_conn() as c:
        for name in z.namelist():
            if not name.endswith('transcript.md'):continue
            raw=z.read(name).decode('utf-8','ignore');title=re.search(r'title:\s*["\']?(.*?)["\']?\s*$',raw,re.M);guest=re.search(r'guest:\s*(.*)$',raw,re.M);url=re.search(r'youtube_url:\s*(.*)$',raw,re.M);body=raw.split('---',2)[-1]
            meta=(guest.group(1).strip() if guest else pathlib.Path(name).parent.name,title.group(1).strip().strip('"') if title else pathlib.Path(name).parent.name,url.group(1).strip() if url else '')
            source=name.split('/',2)[-2]
            for i,ch in enumerate(chunks(body)):
                c.execute('INSERT INTO chunks(source_id,guest,title,source_url,content) VALUES(%s,%s,%s,%s,%s)',(f'{source}-{i}',*meta,ch));added+=1
            episodes+=1
            if episodes>=25:break
        c.commit()
    print(f'Ingested {episodes} episodes / {added} chunks.')
if __name__=='__main__':main()
