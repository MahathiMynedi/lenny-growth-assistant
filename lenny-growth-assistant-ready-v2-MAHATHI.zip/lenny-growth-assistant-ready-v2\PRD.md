# PRD — Lenny Growth Assistant
## Discovery brief
**User/problem:** Product and growth teams need fast, grounded access to Lenny's Podcast insights without learning prompts, models, or infrastructure.
**Success metrics:** ≥90% of evaluated answers include a relevant source; p95 local response target <45s; unsupported questions do not receive fabricated evidence.
**Assumptions:** Evaluator can run Docker and Ollama; transcript data is available online; PostgreSQL is the persistence layer.
**Scope:** Chat, independent sessions, transcript ingestion/chunking, source citations, Ollama demo, optional Anthropic provider, HTML artifact viewer, tests and operational docs. Excluded: multi-user auth and arbitrary executable artifacts.
## Acceptance criteria
- Independent persistent sessions.
- Source-grounded answers with citations.
- Explicit unsupported-answer behavior.
- Provider configurable without code changes.
- Sandboxed artifact viewer.
- Graceful DB/model failures.
- Reproducible Docker startup.
## Implementation plan
1. FastAPI/PostgreSQL. 2. Ingestion/retrieval. 3. Model adapter. 4. Chat/artifacts. 5. Tests/operability.
