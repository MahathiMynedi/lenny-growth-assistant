import psycopg
from psycopg.rows import dict_row
from .config import settings
def get_conn(): return psycopg.connect(settings.database_url,row_factory=dict_row)
def init_db():
    with get_conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY,created_at TIMESTAMPTZ DEFAULT now(),user_metadata JSONB DEFAULT '{}'::jsonb)")
        c.execute("CREATE TABLE IF NOT EXISTS messages(id BIGSERIAL PRIMARY KEY,session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,role TEXT NOT NULL,content TEXT NOT NULL,created_at TIMESTAMPTZ DEFAULT now())")
        c.execute("CREATE TABLE IF NOT EXISTS chunks(id BIGSERIAL PRIMARY KEY,source_id TEXT NOT NULL,guest TEXT,title TEXT,source_url TEXT,content TEXT NOT NULL)")
        c.commit()
