# Manual test plan
1. Open app and confirm Ollama badge. 2. Ask a grounded question and verify sources. 3. Ask unsupported question and verify no fabricated support. 4. Create essay and verify Artifact Viewer. 5. Resize browser. 6. Stop Ollama and verify readable error.
