# Transcript data
Run `python backend/ingest.py` to fetch a bounded demo slice of the public Lenny Podcast transcript archive. The full corpus is not committed.
