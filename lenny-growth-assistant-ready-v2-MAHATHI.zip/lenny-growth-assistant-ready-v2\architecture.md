# Architecture
Browser → FastAPI → PostgreSQL. FastAPI routes requests through transparent lexical transcript retrieval and an LLM adapter (Ollama for the demo, Anthropic optionally). Tables: sessions, messages, chunks. Generated artifacts are HTML-escaped and rendered in an iframe with `sandbox="allow-same-origin"`, so scripts are not permitted. Docker Compose runs PostgreSQL and the API; Ollama stays on the host.
## API
GET /health; POST /sessions; GET /sessions/{id}/messages; POST /chat; POST /artifact
